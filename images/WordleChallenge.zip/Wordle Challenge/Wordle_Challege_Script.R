#David Riegger
#Friday, March 18th, 2022
#Wordle_Challenge

#Completed according to Instruction Sheet

#Big Picture Logic
#The approach that I decided to go for determining the commonality of certain letters within the list provided.
#The logic behind determining the frequency of a particular letter showing up for each word can give a good idea of
#the chances of the letter getting a positive result when used. Combining the probabilities of the individual letters
#within a word will give a good idea of what the overall chances of the word getting a single positive result.
#From there, using probability formulas we can also determine what are the chances of getting a combination of two or more right
#from the probability results of the individual characters.

#The probability of 2 or more of the characters being chosen of any particular word is in essence also the chance of
#NOT getting only one of any of the letters correct and all letters wrong. Essentially:
# % chance 2 or more characters of word == 100% - (% chance all wrong + % chance only single letter correct)

#Final results with ordered from most likely to least likely is in results_table


#Import packages --------------
library(dplyr)
library(tidyverse)
library(tidyselect)
library(stringr)
library(readr)

#Import Wordle Words information-------------
wordle_mystery_words <- read_csv("~/Wordle_Mystery_Words.csv")


#Create Matrix with Words VS Alphabet-----------

#Duplicate Import to protect original dataset
wordle_words <- wordle_mystery_words
#Convert Words into array
all_words = unlist(wordle_words)

#Create Alphabet array
alphabet <- c("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z")

#Create Alphabet Number of Occurances Dataframe
alphabetNum <- NULL

#Loop through each letter in alphabet
for (current_letter in alphabet)
{
  #count number of current letters in each word
  num_letter <- str_count(all_words, pattern = current_letter)
  #add to dataframe
  alphabetNum <- cbind(alphabetNum, current_letter = num_letter)
}
#naming columns
colnames(alphabetNum) <- alphabet
#adding counting results to wordle_words dataframe to validate visually
wordle_words <- cbind(wordle_words, alphabetNum)

#Count number of each type of occurance

#Keeping in mind that some letters show up 2 or three times, it is important to count once per word, and then
#count the number of double or more occurances, and then the chance of a triple occurance. No words exist
#with more than 4 of the same letter. Calculating the values of doubles and triples necessary to find an
#appropriate and accurate value for the words themselves.

#Create Dataframe with Count Results
num_letterResults <- data.frame(apply(alphabetNum, 2, FUN=function(x) length(which(x>0))))
#Count Results of 2 or more of a letter
num_letterResults <- cbind(num_letterResults, data.frame(apply(alphabetNum, 2, FUN=function(x) length(which(x>1)))))
#Count Results of 3 or more of a letter
num_letterResults <- cbind(num_letterResults, data.frame(apply(alphabetNum, 2, FUN=function(x) length(which(x>2)))))
#rename to appropiate names
rownames(num_letterResults) <- alphabet
colnames(num_letterResults) <- c("Min_1", "Min_2", "Min_3")

#determine percent chance of each letter
total <- 2315
num_letterResults <- mutate(num_letterResults, "chance_Min_1" = num_letterResults$Min_1/total)
num_letterResults <- mutate(num_letterResults, "chance_Min_2" = num_letterResults$Min_2/total)
num_letterResults <- mutate(num_letterResults, "chance_Min_3" = num_letterResults$Min_3/total)


#Find words that maximize chance to get positive hits

#At this point, we are going to use the values and percent chance of getting a good hit, and
#add together all the values of any particular word appropriately.

#NOTE: Letter probability will be entered by alphabetical order, not by order in which they 
#appear in the word

#create dataframe to hold information
word_total_chance <- wordle_mystery_words
#add 5 empty columns to help calculate probability of each individual letter
word_total_chance$letter_one <- NA
word_total_chance$letter_two <- NA
word_total_chance$letter_three <- NA
word_total_chance$letter_four <- NA
word_total_chance$letter_five <- NA
#create first for loop that will go through every word
for(i in 1:2315)
{
  #sets the current column for entry back to the first column "letter_one"
  current_entry_column = 2
  #second, nested for loop that will go through every letter of the current word
  for(current_letter in 1:ncol(alphabetNum))
  {
    #following code checks the number of letter of the word
    #if the letter exists, it assigns the respective percentage chance to the next open space in word_total_chance
    if(alphabetNum[i,current_letter] == 0)
    {
    }
    else if(alphabetNum[i,current_letter] == 1)
    {
      word_total_chance[i,current_entry_column] <- num_letterResults[current_letter,4]
      current_entry_column = current_entry_column + 1
    }
    else if(alphabetNum[i,current_letter] == 2)
    {
      word_total_chance[i,current_entry_column] <- num_letterResults[current_letter,4]
      word_total_chance[i,current_entry_column + 1] <- num_letterResults[current_letter,5]
      current_entry_column = current_entry_column + 2
    }
    else if(alphabetNum[i,current_letter] == 3)
    {
      word_total_chance[i,current_entry_column] <- num_letterResults[current_letter,4]
      word_total_chance[i,current_entry_column + 1] <- num_letterResults[current_letter,5]
      word_total_chance[i,current_entry_column + 2] <- num_letterResults[current_letter,6]
      current_entry_column = current_entry_column + 3
    }
  }
}
#create column and calculate chance of 2 or more correct characters (formula explained at top)
word_total_chance$two_or_more <- 1-((1-word_total_chance$letter_one) * (1-word_total_chance$letter_two) * (1-word_total_chance$letter_three) * (1-word_total_chance$letter_four) * (1-word_total_chance$letter_five))
                                + ((word_total_chance$letter_one) * (1-word_total_chance$letter_two) * (1-word_total_chance$letter_three) * (1-word_total_chance$letter_four) * (1-word_total_chance$letter_five))
                                + ((1-word_total_chance$letter_one) * (word_total_chance$letter_two) * (1-word_total_chance$letter_three) * (1-word_total_chance$letter_four) * (1-word_total_chance$letter_five))
                                + ((1-word_total_chance$letter_one) * (1-word_total_chance$letter_two) * (word_total_chance$letter_three) * (1-word_total_chance$letter_four) * (1-word_total_chance$letter_five))
                                + ((1-word_total_chance$letter_one) * (1-word_total_chance$letter_two) * (1-word_total_chance$letter_three) * (word_total_chance$letter_four) * (1-word_total_chance$letter_five))
                                + ((1-word_total_chance$letter_one) * (1-word_total_chance$letter_two) * (1-word_total_chance$letter_three) * (1-word_total_chance$letter_four) * (word_total_chance$letter_five))


#create results table and arrange data
results_table <- as.data.frame(cbind(word_total_chance$Word, word_total_chance$two_or_more))
results_table <- results_table %>% arrange(desc(V2))

#rename columns for better understanding. Otherwise, problem is solved and complete
colnames(results_table) <- c("First_Guess", "Probability_2_or_more_correct_letters")

#final probability can be multiplied by 100 to get percent chance
head(results_table)


#Conclusion
#Added into the zip file is a graph with the top 5 best guesses to maximize your chances of getting at least
#two letters to be chosen. This code took me about 3-ish hours to complete, with a change in
#calculation and strategy brought about by the resource 3b1b below, which compelled me to change
#some of the code to come to a better result. On top of that, I ran into some limitations of the
#code, including some datatype conversions (including datasets) that took awhile to understand
#and debug. Overall, this has been a great exercise in R that helped solidify for me my understandings
#of the abilities R has and what it can do.


#Resources

#https://www.codecademy.com/learn/learn-r
#3B1B: https://www.youtube.com/watch?v=v68zYyaEmEA
#https://www.geeksforgeeks.org/r-programming-language-introduction/
#https://www.tidyverse.org/learn/
#https://www.statology.org/r-guides/
#https://stackoverflow.com/questions/25652758/counting-cells-with-only-special-characters-r

